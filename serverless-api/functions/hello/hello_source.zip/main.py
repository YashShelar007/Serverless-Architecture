# functions/hello/main.py

def hello_world(request):
    # A simple “hello” endpoint
    return "Hello from Yash’s first GCP function!", 200
